# Gem-X Supply Chain Setup Instructions

Refer to the full setup document for detailed instructions.